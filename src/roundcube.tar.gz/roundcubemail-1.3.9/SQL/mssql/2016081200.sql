ALTER TABLE [dbo].[session] DROP COLUMN [created]
GO
